ZX-Spectrum 128K
Original version: github.com/mvvproject/ReVerSE-U16/tree/master/u16_zx128k
Adapted for Altera DE10-Lite
Release: 1
	CPU: T80@4MHz
	RAM: M9K 56K (32K ROM + 8K ROM + 16K RAM)
	SDRAM: 128K (IS42S16320D-7TL)
	Video: HDMI 640x480@60Hz(ZX-Spectrum screen x2 = H:32+256+32; V=24+192+24)
	Int: 60Hz (h_sync_on and v_sync_on)
	Sound: Stereo (Delta-sigma) AY3-8910 + Beeper
	Keyboard: PS2 Keyboard (ScrollLock=CPU Reset, F5=NMI)
	DivMMC: SD/SDHC (Press F5=Go to ESXDOS)
	Tape input: through built-in ADC
